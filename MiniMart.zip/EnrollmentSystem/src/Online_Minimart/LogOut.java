
package Online_Minimart;

import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;


public class LogOut extends javax.swing.JFrame {
    
     private void addHoverEffect(JButton btn, Color hoverColor, Color hoverText) {
    Color originalText = btn.getForeground();   // remember the normal text color

    btn.setOpaque(false);
    btn.setContentAreaFilled(false);            // normal state: no fill, like yours now

    btn.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {   // mouse is over the button
            btn.setOpaque(true);
            btn.setContentAreaFilled(true);
            btn.setBackground(hoverColor);          // solid blue box
            btn.setForeground(hoverText);
        }

        @Override
        public void mouseExited(MouseEvent e) {    // mouse left the button
            btn.setOpaque(false);
            btn.setContentAreaFilled(false);        // back to transparent
            btn.setForeground(originalText);
        }
    });
   }
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(LogOut.class.getName());

   
    public LogOut() {
        initComponents();
  
        Color red = new Color(255, 0, 0);
        Color green = new Color(0, 153, 255);

              addHoverEffect(no,   red, Color.WHITE);
              addHoverEffect(yes,   green, Color.WHITE);
    }
   
     
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        yes = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        no = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        txt1 = new javax.swing.JButton();

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(180, 234, 201));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 100, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        yes.setBackground(new java.awt.Color(0, 102, 0));
        yes.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 13)); // NOI18N
        yes.setForeground(new java.awt.Color(255, 255, 255));
        yes.setIcon(new javax.swing.ImageIcon("C:\\Users\\laniu\\OneDrive\\Pictures\\Java_Picture\\logout (1).png")); // NOI18N
        yes.setText("Yes");
        yes.setBorder(null);
        yes.addActionListener(this::yesActionPerformed);
        jPanel2.add(yes, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, 70, 20));

        jButton5.setBackground(new java.awt.Color(0, 102, 0));
        jButton5.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("to sign out?");
        jButton5.setBorder(null);
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 200, 20));

        no.setBackground(new java.awt.Color(0, 102, 0));
        no.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 13)); // NOI18N
        no.setForeground(new java.awt.Color(255, 255, 255));
        no.setIcon(new javax.swing.ImageIcon("C:\\Users\\laniu\\OneDrive\\Pictures\\Java_Picture\\return (1).png")); // NOI18N
        no.setText("No");
        no.setBorder(null);
        no.addActionListener(this::noActionPerformed);
        jPanel2.add(no, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, 70, 20));

        jButton7.setBackground(new java.awt.Color(0, 102, 0));
        jButton7.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("Are you sure you want ");
        jButton7.setBorder(null);
        jPanel2.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 220, 20));

        jPanel3.setBackground(new java.awt.Color(0, 153, 51));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton3.setBackground(new java.awt.Color(0, 153, 51));
        jButton3.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setIcon(new javax.swing.ImageIcon("C:\\Users\\laniu\\OneDrive\\Pictures\\Java_Picture\\user (1).png")); // NOI18N
        jButton3.setBorder(null);
        jPanel3.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 50, 40));

        txt1.setBackground(new java.awt.Color(0, 153, 51));
        txt1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        txt1.setForeground(new java.awt.Color(255, 255, 255));
        txt1.setText("User");
        txt1.setBorder(null);
        jPanel3.add(txt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 160, 20));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 240, 60));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 240, 240));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 261, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void noActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noActionPerformed
    Products x = new Products();
           x.pack();
           x.setVisible(true);
           x.setLocationRelativeTo(null);
           this.dispose();
    }//GEN-LAST:event_noActionPerformed

    private void yesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yesActionPerformed
    int choice = JOptionPane.showConfirmDialog(this,
        "Are you sure you want to exit?",
        "Exit",
        JOptionPane.YES_NO_OPTION);

if (choice == JOptionPane.YES_OPTION) {
    System.exit(0);
}
this.dispose();
    }//GEN-LAST:event_yesActionPerformed

    
    public static void main(String args[]) {
      
        java.awt.EventQueue.invokeLater(() -> new LogOut().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JButton no;
    private javax.swing.JButton txt1;
    private javax.swing.JButton yes;
    // End of variables declaration//GEN-END:variables
}
