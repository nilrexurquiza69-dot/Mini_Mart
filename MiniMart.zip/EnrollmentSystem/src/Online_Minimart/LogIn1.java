
package Online_Minimart;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;

import javax.swing.JOptionPane;


public class LogIn1 extends javax.swing.JFrame {
    
private void addHoverEffect(JButton btn, Color hoverColor, Color hoverText) {
    Color originalText = btn.getForeground();   // remember the normal text color

    btn.setOpaque(false);
    btn.setContentAreaFilled(false);            // normal state: no fill, like yours now

    btn.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {   // mouse is over the button
            btn.setOpaque(true);
            btn.setContentAreaFilled(true);
            btn.setBackground(hoverColor);          // solid blue box
            btn.setForeground(hoverText);
        }

        @Override
        public void mouseExited(MouseEvent e) {    // mouse left the button
            btn.setOpaque(false);
            btn.setContentAreaFilled(false);        // back to transparent
            btn.setForeground(originalText);
        }
    });
}
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(LogIn1.class.getName());

    
    public LogIn1() {
        initComponents();
        
        Color blue = new Color(0, 153, 255);
        Color yellowgreen = new Color(0, 255, 51);
        Color yellow = new Color(204, 204, 0);

              addHoverEffect(b1,   yellowgreen, Color.WHITE);
              addHoverEffect(b2,   blue, Color.WHITE);
              addHoverEffect(b3,   yellow, Color.WHITE);
              addHoverEffect(b4,   blue, Color.WHITE);
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        pass = new javax.swing.JPasswordField();
        b1 = new javax.swing.JButton();
        b4 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        C1 = new javax.swing.JCheckBox();
        b3 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        b2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(177, 231, 199));
        jPanel1.setPreferredSize(new java.awt.Dimension(600, 600));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 102, 0));
        jPanel2.setPreferredSize(new java.awt.Dimension(600, 500));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Full Name:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        name.setBackground(new java.awt.Color(0, 102, 0));
        name.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        name.setForeground(new java.awt.Color(255, 255, 255));
        name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel2.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 180, 30));

        jLabel5.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Password:\n");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        pass.setBackground(new java.awt.Color(0, 102, 0));
        pass.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        pass.setForeground(new java.awt.Color(255, 255, 255));
        pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel2.add(pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 170, 180, 30));

        b1.setBackground(new java.awt.Color(0, 102, 0));
        b1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 18)); // NOI18N
        b1.setForeground(new java.awt.Color(255, 255, 255));
        b1.setText("Log In");
        b1.setBorder(null);
        b1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                b1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                b1MouseExited(evt);
            }
        });
        b1.addActionListener(this::b1ActionPerformed);
        jPanel2.add(b1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 250, 210, 34));

        b4.setBackground(new java.awt.Color(0, 102, 0));
        b4.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        b4.setForeground(new java.awt.Color(0, 153, 255));
        b4.setText("Sign Up.");
        b4.setBorder(null);
        b4.addActionListener(this::b4ActionPerformed);
        jPanel2.add(b4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 460, 60, -1));

        jLabel6.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Or LogIn with");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 310, 110, -1));

        jLabel1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 38)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("LogIn Now");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 260, -1));

        C1.setBackground(new java.awt.Color(0, 102, 0));
        C1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        C1.setForeground(new java.awt.Color(255, 255, 255));
        C1.setText("Show Password");
        C1.addActionListener(this::C1ActionPerformed);
        jPanel2.add(C1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 210, -1, -1));

        b3.setBackground(new java.awt.Color(0, 102, 0));
        b3.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        b3.setForeground(new java.awt.Color(204, 204, 0));
        b3.setText("LogIn with Google ");
        b3.setBorder(null);
        b3.addActionListener(this::b3ActionPerformed);
        jPanel2.add(b3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, 250, 40));

        jLabel7.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("You don't have an account?");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 460, 210, -1));

        b2.setBackground(new java.awt.Color(0, 102, 0));
        b2.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        b2.setForeground(new java.awt.Color(0, 153, 255));
        b2.setText("LogIn with Facebook");
        b2.setBorder(null);
        b2.addActionListener(this::b2ActionPerformed);
        jPanel2.add(b2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 330, 250, 40));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 330, 510));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 349, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
     if (name.getText().equals("")){
    JOptionPane.showMessageDialog(null, "Please fill out the Fullname!");
     }   
        if (pass.getText().equals("")){
    JOptionPane.showMessageDialog(null, "Please fill out the Password!");
     }   
     else {
    JOptionPane.showMessageDialog(null, "You dont have an account, please Sign Up first!!!", "Message", JOptionPane.ERROR_MESSAGE);
}
// TODO add your handling code here:
    }//GEN-LAST:event_b1ActionPerformed

    private void b4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b4ActionPerformed
    Signup x = new Signup();
           x.setVisible(true);
           x.pack();
           x.setLocationRelativeTo(null);
           this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_b4ActionPerformed
  
    private void C1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_C1ActionPerformed
     if (C1.isSelected()){
            pass.setEchoChar((char)0);
        }
        else {
            pass.setEchoChar('*');
        }      
        // TODO add your handling code here:
    }//GEN-LAST:event_C1ActionPerformed

    private void b1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b1MouseEntered
   b1.setOpaque(true);
   b1.setContentAreaFilled(true);
   b1.setBackground(new Color(0, 255, 51));   // TODO add your handling code here:
    }//GEN-LAST:event_b1MouseEntered

    private void b1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_b1MouseExited
   b1.setContentAreaFilled(false);
   b1.setOpaque(false);    // TODO add your handling code here:
    }//GEN-LAST:event_b1MouseExited

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
    JOptionPane.showMessageDialog(null, "Facebook Site is Coming Soon!!!", "Message", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_b2ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
     JOptionPane.showMessageDialog(null, "Google Site is Coming Soon!!!", "Message", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_b3ActionPerformed

      
  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox C1;
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JButton b4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField name;
    private javax.swing.JPasswordField pass;
    // End of variables declaration//GEN-END:variables
}
