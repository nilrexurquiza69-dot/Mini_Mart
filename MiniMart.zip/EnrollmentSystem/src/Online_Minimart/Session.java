
package Online_Minimart;

   
public class Session {
    private static String username = "User";
    
    public static String customerName = "";
    
    public static void setUsername(String name) {
        username = name;
    }

    public static String getUsername() {
        return username;
    }
}
