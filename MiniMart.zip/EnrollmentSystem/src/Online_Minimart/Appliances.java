package Online_Minimart;
   
import javax.swing.JOptionPane;
//kani is para maka add, og maka remove og maka read sa table rows!!
import javax.swing.table.DefaultTableModel;
//Kani nga import is para sa Status: para ma highlight og green ang mga Instock og mga Column kasabot mo!!
import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableCellRenderer;
//Kani nga import is para sa mga font/Text para presentable hehe!!
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.*;
//Kani nga import kay para sa color sa mga buttons!! 
import java.awt.Color;
import javax.swing.JButton;
  
public class Appliances extends javax.swing.JFrame {
private final Color ACTIVE_BG   = new Color(250, 250, 250);    //Kani is green highligh lang!!
private final Color HIGH_BG   =   new Color(221, 235, 221);  //Dria kay sidebar color ra!!
private final Color NORMAL_FG   = new Color(30, 40, 35);    //Dito naman ayy para sa textColor!!
private final Color HOVER_BG    = new Color(0, 153, 0);  //pwede ramo mangita sa BG color sa properties!!

private JButton[] Buttons;
private JButton activeButton;

private void styleMenuButton(JButton btn) {
    btn.setOpaque(true);
    btn.setContentAreaFilled(true);
    btn.setBorderPainted(false);
    btn.setFocusPainted(false);
    btn.setBackground(HIGH_BG);
    btn.setForeground(NORMAL_FG);
}

private void setActive(JButton selected) {
    for (JButton b : Buttons) {
        b.setBackground(HIGH_BG);
        b.setForeground(NORMAL_FG);
    }
    selected.setBackground(ACTIVE_BG);
    activeButton = selected;
}

private void addHover(JButton btn) {
    btn.addMouseListener(new java.awt.event.MouseAdapter() {
        @Override
        public void mouseEntered(java.awt.event.MouseEvent e) {
            if (btn != activeButton) btn.setBackground(HOVER_BG);
        }
        @Override
        public void mouseExited(java.awt.event.MouseEvent e) {
            if (btn != activeButton) btn.setBackground(HIGH_BG);
        }
    });
}
//kani nga code kay para pag click nato sa add to receipt kay ma recieve sa PayList!!
//Or mga data nato sa Products/Table kay maabot sa PayList!!
//Pero sa code nako kay ang ma recieve niya kay ang ProductName, Category, og Price kana lang!! 
private PayList payList;

private void searchGoods() {
    String keyword = txt.getText().trim().toLowerCase();
    if (keyword.equals("select goods....")) keyword = "";  //Kani kay iignore lng niya ang text nga search goods!!
}
//Kani is para ma full copy niya ang tanang rows, gamit ni sya as the search source Kasabot ka!!
private java.util.ArrayList<Object[]> allRows = new java.util.ArrayList<>();   

//Dinhi nga code kay para sa mga style sa table!! 
private void styleTable(JTable table) {
    table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    table.setRowHeight(34);
    table.setShowVerticalLines(false);
    table.setShowHorizontalLines(true);
    table.setGridColor(new Color(224, 224, 224));
    table.setIntercellSpacing(new Dimension(0, 1));
    table.setSelectionBackground(new Color(200, 230, 201));
    table.setSelectionForeground(Color.BLACK);
    table.setFillsViewportHeight(true);

    // Kani is sa Header sa Table para choyy tan-awon hehehe, and para ma occupied sd niya ang mga text sa table bali ma plastar na ba!!
    JTableHeader header = table.getTableHeader();
    header.setReorderingAllowed(false);
    header.setPreferredSize(new Dimension(header.getWidth(), 38));
    header.setDefaultRenderer(new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v,
                boolean sel, boolean foc, int r, int c) {
            super.getTableCellRendererComponent(t, v, sel, foc, r, c);
            setBackground(new Color(46, 125, 50));
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 15));
            setHorizontalAlignment(CENTER);
            setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(76, 155, 80)));
            return this;
        }
    });

    // Kani kay sa Body cells/padding Para ma wla ang mga linya2 sa table
    table.setDefaultRenderer(Object.class, new RowRenderer(SwingConstants.LEFT));

    table.getColumnModel().getColumn(0).setCellRenderer(new RowRenderer(SwingConstants.LEFT));   // Product Name!!
    table.getColumnModel().getColumn(1).setCellRenderer(new RowRenderer(SwingConstants.LEFT));   // Category!!
    table.getColumnModel().getColumn(2).setCellRenderer(new RowRenderer(SwingConstants.RIGHT));  // Price!!
    table.getColumnModel().getColumn(3).setCellRenderer(new RowRenderer(SwingConstants.CENTER)); // Stock!!

    table.getColumnModel().getColumn(0).setPreferredWidth(170);
    table.getColumnModel().getColumn(1).setPreferredWidth(220);
    table.getColumnModel().getColumn(2).setPreferredWidth(90);
    table.getColumnModel().getColumn(3).setPreferredWidth(110);
    table.getColumnModel().getColumn(4).setPreferredWidth(110);
}
//Kani is Reusable renderer para sa mga normal na columns!!
private static class RowRenderer extends DefaultTableCellRenderer {
    private final int align;
    
     RowRenderer(int align) {
        this.align = align;
    }
    @Override
    public Component getTableCellRendererComponent(JTable t, Object v,
            boolean sel, boolean foc, int r, int c) {
        super.getTableCellRendererComponent(t, v, sel, foc, r, c);
        setHorizontalAlignment(align);
        setBorder(new EmptyBorder(0, 10, 0, 10));         
        setFont(new Font("Segoe UI", Font.PLAIN, 14));

        if (!sel) {
            setBackground(r % 2 == 0 ? Color.WHITE : new Color(245, 250, 245)); 
            setForeground(new Color(33, 33, 33));
        }
         //Kani is ang hover para maipa kita niya ang tanang full text!!
        setToolTipText(v == null ? null : v.toString());  
        return this;
    }
}
//Kani is para ma remove ang extra Scroll sa Table!!
private void removeOuterScroll(JTable table) {
    Container inner = SwingUtilities.getAncestorOfClass(JScrollPane.class, table);
    if (inner == null || inner.getParent() == null) return;

    Container outer = SwingUtilities.getAncestorOfClass(JScrollPane.class, inner.getParent());
    if (outer instanceof JScrollPane) {
        JScrollPane sp = (JScrollPane) outer;
        sp.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        sp.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setBorder(null);
    }
}

private void loadAllRows() {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    allRows.clear();
    for (int i = 0; i < model.getRowCount(); i++) {
        Object[] row = new Object[model.getColumnCount()];
        for (int j = 0; j < model.getColumnCount(); j++) {
            row[j] = model.getValueAt(i, j);
        }
        allRows.add(row);
    }
}

private void searchTable(String keyword) {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0);                      
    keyword = keyword.trim().toLowerCase();

    for (int i = 0; i < allRows.size(); i++) { 
        Object[] row = allRows.get(i);
        boolean found = false;

        for (int j = 0; j < row.length; j++) {  
            if (row[j] != null && row[j].toString().toLowerCase().contains(keyword)) {
                found = true;
                break;
            }
        }

        if (found) {
            model.addRow(row);                 
        }
    }
}
   
private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Appliances.class.getName());

    public Appliances() {
        initComponents();
        fillTable(); //kani kay para ma fill niya ang table!!
        loadAllRows(); //Kani kay para mai load niya ang tanang rows!!  
        styleTable(jTable1); //Kani para sa style or design sa Jtable!!
        removeOuterScroll(jTable1); //kani para ma remove ang isa ka scroll!!
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));//Kani nga component is para sa mouse cursor!!
        Buttons = new JButton[] { //Kini nga components kay responsible sa mga highlight buttons!!
        btn1, btn2, btn3, btn4
    };
       //Kani nga code og wla ni, dli mo gawas iyang greenLight color!!
       for (JButton b : Buttons) {
        styleMenuButton(b);
        addHover(b);
    }
        
    final String HINT = "Select Goods....";
    //Kani kay para transparent tan-awon ang Select Goods..!!
    txt.setOpaque(false);
    txt.setBackground(new java.awt.Color(0, 0, 0, 0));
    txt.setBorder(javax.swing.BorderFactory.createEmptyBorder());

    //Kani kay kapag I click nimo ang seclectGoods kay mawala, and og dli nimo click ang selectGoods kay mag appear na sd ang selectGoods!!
    txt.setText(HINT);
    txt.setForeground(java.awt.Color.GRAY);
    txt.addFocusListener(new java.awt.event.FocusAdapter() {
        @Override
        public void focusGained(java.awt.event.FocusEvent e) {
            if (txt.getText().equals(HINT)) {
                txt.setText("");
                txt.setForeground(new java.awt.Color(40, 40, 40));
            }
        }
        @Override
        public void focusLost(java.awt.event.FocusEvent e) {
            if (txt.getText().trim().isEmpty()) {
                txt.setText(HINT);
                txt.setForeground(java.awt.Color.GRAY);
            }
        }
    });

    //Kani nga code kay maka search ka while ga type2 ka!!
    txt.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
        public void insertUpdate(javax.swing.event.DocumentEvent e)  { searchGoods(); }
        public void removeUpdate(javax.swing.event.DocumentEvent e)  { searchGoods(); }
        public void changedUpdate(javax.swing.event.DocumentEvent e) { searchGoods(); }
    });

    jTable1.getColumn("Status").setCellRenderer(new DefaultTableCellRenderer() {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) {

        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        setHorizontalAlignment(JLabel.CENTER);

        String status = value == null ? "" : value.toString().trim();

        if (status.equalsIgnoreCase("In Stock")) {
            setBackground(new Color(200, 230, 201));   //Kini is light green!!
            setForeground(new Color(46, 125, 50));     //Dinhi is dark green nga text!!
        } else if (status.equalsIgnoreCase("Low Stock")) {
            setBackground(new Color(255, 236, 179));   //Dri kay light yellow!!
            setForeground(new Color(191, 144, 0));
        } else if (status.equalsIgnoreCase("Out of Stock")) {
            setBackground(new Color(255, 205, 210));   //And last kay light red!!
            setForeground(new Color(183, 28, 28));
        } else {
            setBackground(Color.WHITE);
            setForeground(Color.BLACK);
        }

        //Dri kay dapat I keep lng nimo ang normal selection color kapag ang row kay gi-clicked nimo!!
        if (isSelected) {
            setBackground(table.getSelectionBackground());
            setForeground(table.getSelectionForeground());
        }
        return this;
    }
    
});
}
    public void setUsername(String username) {
    txt1.setText(username);   // shows the logged-in name
}
private void fillTable() {
  ((DefaultTableModel) jTable1.getModel()).setColumnIdentifiers(new String[]{"Product Name","Category","Price","Stock","Status"});
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0);   
      
    //Dri nko gina butang ang tanang data saamoang product kapoya taas kaayo maka patay og oras haha!!
    Object[][] data = {
    {"Rice Cooker", "Kitchen Appliance (1.8 L)", 1450.00, "30     Units",  "In Stock"},
    {"Electric Kettle", "Kitchen Appliance (1.7 L)", 850.00, "40     Units",  "In Stock"},
    {"Microwave Oven", "Kitchen Appliance (20 L)", 4500.00, "15     Units",  "In Stock"},
    {"Blender", "Kitchen Appliance (1.5 L)", 1800.00, "25     Units",  "In Stock"},
    {"Induction Cooker", "Kitchen Appliance (1 pc)", 2500.00, "20     Units",  "In Stock"},
    {"Stand Fan", "Cooling Appliance (16 in)", 1300.00, "35     Units",  "In Stock"},
    {"Wall Fan", "Cooling Appliance (16 in)", 1100.00, "30     Units",  "In Stock"},
    {"Ceiling Fan", "Cooling Appliance (56 in)", 2200.00, "20     Units",  "In Stock"},
    {"Air Cooler", "Cooling Appliance (1 pc)", 3800.00, "12     Units",  "In Stock"},
    {"Window Aircon", "Cooling Appliance (1 HP)", 18500.00, "8      Units",  "In Stock"},
    {"Washing Machine", "Laundry Appliance (7 kg)", 9500.00, "10     Units",  "In Stock"},
    {"Spin Dryer", "Laundry Appliance (6 kg)", 4200.00, "12     Units",  "In Stock"},
    {"Electric Iron", "Laundry Appliance (1 pc)", 950.00, "45     Units",  "In Stock"},
    {"Vacuum Cleaner", "Cleaning Appliance (1 pc)", 3200.00, "18     Units",  "In Stock"},
    {"Steam Mop", "Cleaning Appliance (1 pc)", 2800.00, "14     Units",  "In Stock"},
    {"Refrigerator", "Refrigeration (Single Door)", 11500.00, "10     Units",  "In Stock"},
    {"Two-Door Refrigerator", "Refrigeration (Two Door)", 19800.00, "6      Units",  "In Stock"},
    {"Chest Freezer", "Refrigeration (200 L)", 14000.00, "7      Units",  "In Stock"},
    {"Water Dispenser", "Refrigeration (Hot & Cold)", 4800.00, "16     Units",  "In Stock"},
    {"Mini Fridge", "Refrigeration (90 L)", 6500.00, "12     Units",  "In Stock"},
    {"LED Television", "Electronics (32 in)", 9800.00, "12     Units",  "In Stock"},
    {"Smart TV", "Electronics (43 in)", 16500.00, "8      Units",  "In Stock"},
    {"Bluetooth Speaker", "Electronics (1 pc)", 1600.00, "35     Units",  "In Stock"},
    {"Electric Fan Remote", "Electronics (1 pc)", 350.00, "60     Units",  "In Stock"},
    {"Power Strip", "Electronics (4 Outlets)", 450.00, "80     Units",  "In Stock"},
    {"Hair Dryer", "Personal Care (1 pc)", 900.00, "30     Units",  "In Stock"},
    {"Hair Straightener", "Personal Care (1 pc)", 1200.00, "25     Units",  "In Stock"},
    {"Electric Shaver", "Personal Care (1 pc)", 1100.00, "28     Units",  "In Stock"},
    {"Electric Toothbrush", "Personal Care (1 pc)", 750.00, "40     Units",  "In Stock"},
    {"Hair Clipper", "Personal Care (1 pc)", 980.00, "22     Units",  "In Stock"},
    {"LED Bulb", "Lighting (9 W)", 120.00, "150   Units", "In Stock"},
    {"Rechargeable Lamp", "Lighting (1 pc)", 650.00, "45     Units",  "In Stock"},
    {"Emergency Light", "Lighting (1 pc)", 800.00, "35     Units",  "In Stock"},
    {"Flashlight", "Lighting (1 pc)", 280.00, "70     Units",  "In Stock"},
    {"Ceiling Light", "Lighting (18 W)", 550.00, "40     Units",  "In Stock"},
    {"Toaster", "Small Kitchen Appliance (2 Slice)", 1250.00, "28     Units",  "In Stock"},
    {"Air Fryer", "Small Kitchen Appliance (4 L)", 3500.00, "20     Units",  "In Stock"},
    {"Coffee Maker", "Small Kitchen Appliance (1.2 L)", 2300.00, "18     Units",  "In Stock"},
    {"Electric Griddle", "Small Kitchen Appliance (1 pc)", 1900.00, "16     Units",  "In Stock"},
    {"Sandwich Maker", "Small Kitchen Appliance (1 pc)", 1050.00, "24     Units",  "In Stock"},
    {"Dilldough",  "Essentials",   200.00,      "100 Units,",  "Full Stack"}
        
    };

    for (int i = 0; i < data.length; i++) {
        model.addRow(data[i]);
    }
}
private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {
  
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        txt = new javax.swing.JTextField();
        Search = new javax.swing.JButton();
        Add = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        btn2 = new javax.swing.JButton();
        btn3 = new javax.swing.JButton();
        btn1 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btn6 = new javax.swing.JButton();
        btn7 = new javax.swing.JButton();
        btn4 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(223, 233, 229));
        jPanel1.setPreferredSize(new java.awt.Dimension(1040, 490));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 90, -1, -1));

        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Product Name", "Category", "Price", "Stock", "Status"
            }
        ));
        jTable1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                jTable1MouseMoved(evt);
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jScrollPane3.setViewportView(jScrollPane1);

        jPanel1.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 580, 340));

        jPanel2.setBackground(new java.awt.Color(168, 244, 198));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txt.setBackground(new java.awt.Color(158, 248, 196));
        txt.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        txt.setText("Select Goods....");
        txt.setBorder(null);
        txt.addActionListener(this::txtActionPerformed);
        jPanel2.add(txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 290, 20));

        Search.setBackground(new java.awt.Color(175, 242, 206));
        Search.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        Search.setText("Search");
        Search.setBorder(null);
        Search.addActionListener(this::SearchActionPerformed);
        jPanel2.add(Search, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 10, 70, 20));

        Add.setBackground(new java.awt.Color(165, 246, 192));
        Add.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        Add.setText("Add ");
        Add.setBorder(null);
        Add.addActionListener(this::AddActionPerformed);
        jPanel2.add(Add, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, 70, 20));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 90, 580, 40));

        jPanel3.setBackground(new java.awt.Color(0, 153, 51));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon("C:\\Users\\laniu\\OneDrive\\Pictures\\Java_Picture\\online-shoping.png")); // NOI18N
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 100, 80));

        jLabel6.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText(".Fresh Items, Everyday.");
        jPanel3.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, 190, -1));

        jLabel7.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Mini Mart");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 20, 150, -1));

        txt1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        txt1.setForeground(new java.awt.Color(255, 255, 255));
        txt1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        txt1.setText("User");
        jPanel3.add(txt1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 50, 130, 20));

        jButton1.setBackground(new java.awt.Color(0, 153, 0));
        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\laniu\\OneDrive\\Pictures\\Java_Picture\\user (1).png")); // NOI18N
        jButton1.setBorder(null);
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 10, 50, -1));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 80));

        jPanel4.setBackground(new java.awt.Color(220, 236, 229));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btn2.setBackground(new java.awt.Color(225, 234, 230));
        btn2.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        btn2.setText("Food Groups");
        btn2.setBorder(null);
        btn2.addActionListener(this::btn2ActionPerformed);
        jPanel4.add(btn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, 110, 30));

        btn3.setBackground(new java.awt.Color(222, 237, 230));
        btn3.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        btn3.setText("Appliances");
        btn3.setBorder(null);
        btn3.addActionListener(this::btn3ActionPerformed);
        jPanel4.add(btn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 110, 30));

        btn1.setBackground(new java.awt.Color(224, 235, 230));
        btn1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        btn1.setText(" Essentials");
        btn1.setBorder(null);
        btn1.addActionListener(this::btn1ActionPerformed);
        jPanel4.add(btn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 110, 30));

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\laniu\\OneDrive\\Pictures\\Java_Picture\\fruits-and-vegetables-removebg-preview (1).png")); // NOI18N
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 80, -1));

        btn6.setBackground(new java.awt.Color(225, 237, 231));
        btn6.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        btn6.setForeground(new java.awt.Color(0, 102, 51));
        btn6.setText("Big Need's");
        btn6.setBorder(null);
        jPanel4.add(btn6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 380, 100, 20));

        btn7.setBackground(new java.awt.Color(225, 237, 231));
        btn7.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        btn7.setForeground(new java.awt.Color(0, 102, 51));
        btn7.setText("Small Store");
        btn7.setBorder(null);
        jPanel4.add(btn7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 100, 20));

        btn4.setBackground(new java.awt.Color(216, 237, 223));
        btn4.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        btn4.setText("Link");
        btn4.setBorder(null);
        btn4.addActionListener(this::btn4ActionPerformed);
        jPanel4.add(btn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 80, 30));

        jLabel9.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 102, 0));
        jLabel9.setText("Goods");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, -1, -1));

        jLabel10.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 102, 0));
        jLabel10.setText("Choose ");
        jPanel4.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, -1));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 120, 410));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 719, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 485, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtActionPerformed
     if (txt.getText().equals("Select Goods....")) {
         txt.setText("");   //Kini is gina clear lng niya ang placeholder text!!
    }   
    }//GEN-LAST:event_txtActionPerformed

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
     searchTable(txt.getText());
       
    }//GEN-LAST:event_SearchActionPerformed
  
    private void AddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddActionPerformed
int row = jTable1.getSelectedRow();
    if (row == -1) {
        javax.swing.JOptionPane.showMessageDialog(this, "Please select a product first.");
        return;
    }

    String name     = jTable1.getValueAt(row, 0).toString();
    String category = jTable1.getValueAt(row, 1).toString();
    double price    = Double.parseDouble(jTable1.getValueAt(row, 2).toString());

    PayList pay = PayList.getInstance();   // NOT new PayList()
    pay.addItem(name, category, price);
    pay.setVisible(true);
    pay.toFront();
    
    }//GEN-LAST:event_AddActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
     
    
    }//GEN-LAST:event_jTable1MouseClicked

    private void jTable1MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseMoved
    //Kani code is para sa mouse nato, para murag kamot2 tan-awon iyang cursor!!   
    int row = jTable1.rowAtPoint(evt.getPoint());

     if (row >= 0) {
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
    } else {
        jTable1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }   
    }//GEN-LAST:event_jTable1MouseMoved

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn4ActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
    FoodGroup x = new FoodGroup();
              x.pack();
              x.setVisible(true);
              x.setLocationRelativeTo(null);
              this.dispose();
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
    Products x = new Products();
             x.pack();
             x.setVisible(true);
             x.setLocationRelativeTo(null);
             this.dispose();
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
     Appliances x = new Appliances();
             x.pack();
             x.setVisible(true);
             x.setLocationRelativeTo(null);
             this.dispose();    
    }//GEN-LAST:event_btn3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      int choice = JOptionPane.showConfirmDialog(this,
        "Are you sure you want to exit?",
        "Exit",
        JOptionPane.YES_NO_OPTION);

if (choice == JOptionPane.YES_OPTION) {
}
        LogOut x = new LogOut();
           x.pack();
           x.setVisible(true);
           x.setLocationRelativeTo(null);
           this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed
   public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(() -> new Appliances().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Add;
    private javax.swing.JButton Search;
    private javax.swing.JButton btn1;
    private javax.swing.JButton btn2;
    private javax.swing.JButton btn3;
    private javax.swing.JButton btn4;
    private javax.swing.JButton btn6;
    private javax.swing.JButton btn7;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField txt;
    private javax.swing.JLabel txt1;
    // End of variables declaration//GEN-END:variables
}
