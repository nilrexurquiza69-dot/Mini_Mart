
package Online_Minimart;

//Kani nga import kay para sa color sa mga buttons!! 
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Signup extends javax.swing.JFrame {
    
private String registeredUsername = "";
private String registeredPassword = "";

//
    private void addHoverEffect(JButton btn, Color hoverColor, Color hoverText) {
    Color originalText = btn.getForeground();   //Dri kay ma remember niya normal text color!!

    btn.setOpaque(false);
    btn.setContentAreaFilled(false);            //Kani dri is normal state lang: kung baga no fill, like yours now!!

    btn.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {   //Dri is ang mouse is over the button!!
            btn.setOpaque(true);
            btn.setContentAreaFilled(true);
            btn.setBackground(hoverColor);          // dri is solid blue box lang!!
            btn.setForeground(hoverText);
        }

        @Override
        public void mouseExited(MouseEvent e) {    // mouse left the button
            btn.setOpaque(false);
            btn.setContentAreaFilled(false);        // Kani is mo balik sa pagka transparent!!
            btn.setForeground(originalText);
        }
    });
}

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Signup.class.getName());

   
    public Signup() {
        initComponents();
        //Kini nga components kay responsible sa mga highlight buttons!!
        Color blue = new Color(0, 153, 255);
        Color yellow = new Color(204, 204, 0);
              addHoverEffect(Sign,   blue, Color.WHITE);
              addHoverEffect(b2,   blue, Color.WHITE);
              addHoverEffect(b3,   yellow, Color.WHITE);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        Sign = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Pass = new javax.swing.JPasswordField();
        jLabel2 = new javax.swing.JLabel();
        txt = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        mail = new javax.swing.JTextField();
        C1 = new javax.swing.JCheckBox();
        b3 = new javax.swing.JButton();
        b2 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();

        jTextField1.setText("jTextField1");

        jPasswordField1.setText("jPasswordField1");

        jButton1.setText("jButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(182, 238, 204));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 102, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Sign.setBackground(new java.awt.Color(0, 102, 0));
        Sign.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        Sign.setForeground(new java.awt.Color(0, 153, 255));
        Sign.setText("SignUp");
        Sign.setBorder(null);
        Sign.addActionListener(this::SignActionPerformed);
        jPanel2.add(Sign, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 268, 210, 40));

        jLabel1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Password:");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, -1, -1));

        Pass.setBackground(new java.awt.Color(0, 102, 0));
        Pass.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        Pass.setForeground(new java.awt.Color(255, 255, 255));
        Pass.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        Pass.addActionListener(this::PassActionPerformed);
        jPanel2.add(Pass, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 200, 170, 30));

        jLabel2.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Full Name:");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        txt.setBackground(new java.awt.Color(0, 102, 0));
        txt.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        txt.setForeground(new java.awt.Color(255, 255, 255));
        txt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        txt.addActionListener(this::txtActionPerformed);
        jPanel2.add(txt, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 97, 170, 30));

        jLabel3.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Or  LogIn with");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 330, -1, -1));

        jLabel4.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 38)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("SingUp Now");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, -1, -1));

        mail.setBackground(new java.awt.Color(0, 102, 0));
        mail.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        mail.setForeground(new java.awt.Color(255, 255, 255));
        mail.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jPanel2.add(mail, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 147, 170, 30));

        C1.setBackground(new java.awt.Color(0, 102, 0));
        C1.setFont(new java.awt.Font("Rockwell Extra Bold", 0, 12)); // NOI18N
        C1.setForeground(new java.awt.Color(255, 255, 255));
        C1.setText("Show Password");
        C1.addActionListener(this::C1ActionPerformed);
        jPanel2.add(C1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 240, -1, -1));

        b3.setBackground(new java.awt.Color(0, 102, 0));
        b3.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        b3.setForeground(new java.awt.Color(204, 204, 0));
        b3.setText("LogIn with Google");
        b3.setBorder(null);
        b3.addActionListener(this::b3ActionPerformed);
        jPanel2.add(b3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 410, 250, 40));

        b2.setBackground(new java.awt.Color(0, 102, 0));
        b2.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        b2.setForeground(new java.awt.Color(0, 153, 255));
        b2.setText("LogIn with Facebook");
        b2.setBorder(null);
        b2.addActionListener(this::b2ActionPerformed);
        jPanel2.add(b2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, 250, 40));

        jLabel5.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Email Acc:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 330, 500));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 349, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SignActionPerformed
                                              
   String inputUsername = txt.getText().trim();
   String inputEmail = mail.getText().trim();
    String inputPassword = new String(Pass.getPassword()).trim();

    if (inputUsername.isEmpty() || inputPassword.isEmpty() ||inputEmail.isEmpty()) {
        javax.swing.JOptionPane.showMessageDialog(this,
            "Username, Email, and password cannot be empty!",
            "Error",
            javax.swing.JOptionPane.ERROR_MESSAGE);
        return;
    }
  
    // Send the credentials to the login class
    LogIn2.register(inputUsername, inputPassword);

    javax.swing.JOptionPane.showMessageDialog(this,
        "Sign-up successful! You can now log in using these details.",
        "Success",
        javax.swing.JOptionPane.INFORMATION_MESSAGE);

    txt.setText("");
    mail.setText("");
    Pass.setText("");

    // Go back to the login form (not StudentForm1)
    LogIn2 login = new LogIn2();
    login.setVisible(true);
    login.pack();
    login.setLocationRelativeTo(null);
    this.dispose();

        // TODO add your handling code here:
    }//GEN-LAST:event_SignActionPerformed

    private void PassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PassActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PassActionPerformed

    private void txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtActionPerformed

    private void C1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_C1ActionPerformed
       if (C1.isSelected()){
            Pass.setEchoChar((char)0);
        }
        else {
            Pass.setEchoChar('*');
        }             
    }//GEN-LAST:event_C1ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
    JOptionPane.showMessageDialog(null, "Facebook Site is Coming Soon!!!", "Message", JOptionPane.INFORMATION_MESSAGE);    
    }//GEN-LAST:event_b2ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
    JOptionPane.showMessageDialog(null, "Google Site is Coming Soon!!!", "Message", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_b3ActionPerformed

    
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(() -> new Signup().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox C1;
    private javax.swing.JPasswordField Pass;
    private javax.swing.JButton Sign;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField mail;
    private javax.swing.JTextField txt;
    // End of variables declaration//GEN-END:variables
}
