package Online_Minimart;
  
//Ang gamit ani nga import is para makuha nato ang mga DecimalFormat sa mga numbers!!
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;
 //Ang gamit ani nga import is para makuha nato ang list sa mga values!!
import java.util.Vector;
import javax.swing.JButton;
//kani is para maka add, og maka remove og ma nat read sa table rows!!
import javax.swing.table.DefaultTableModel;

public class PayList extends javax.swing.JFrame {
    
    // the ONE and only PayList window
    private static PayList instance;

    public static PayList getInstance() {
        if (instance == null) {
            instance = new PayList();
        }
        return instance;
    }
    //
    private void addHoverEffect(JButton btn, Color hoverColor, Color hoverText) {
    Color originalText = btn.getForeground();   // remember the normal text color

    btn.setOpaque(false);
    btn.setContentAreaFilled(false);            // normal state: no fill, like yours now

    btn.addMouseListener(new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent e) {   // mouse is over the button
            btn.setOpaque(true);
            btn.setContentAreaFilled(true);
            btn.setBackground(hoverColor);          // solid blue box
            btn.setForeground(hoverText);
        }

        @Override
        public void mouseExited(MouseEvent e) {    // mouse left the button
            btn.setOpaque(false);
            btn.setContentAreaFilled(false);        // back to transparent
            btn.setForeground(originalText);
        }
    });
}
    
//Kani kay para makuha nato ang Total/Price sa Products nga frame!!
private double totalAmount = 0;

public void addItem(String name, String category, double price) {
    //Dria kay para makuha ang table model sa new rows para add niya sa table!!
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    DecimalFormat df = new DecimalFormat("#,##0.00");
    
    //Dria kay ma Add niya ang mga product (name, category, price with ₱) Sa bag-ong table sa PayList!!
    model.addRow(new Object[]{name, category, "₱ " + df.format(price)});

    totalAmount += price;
    Total.setText("₱ " + df.format(totalAmount)); //Dinhi nga side is para ma Show niya ang updated sa total padulong sa Total label!!
}
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PayList.class.getName());

    public PayList() {
        initComponents(); 
        //
        setDefaultCloseOperation(javax.swing.WindowConstants.HIDE_ON_CLOSE);
        //
        Color yellowgreen = new Color(0, 255, 51);
        Color blue = new Color(0, 102, 255);
        Color red = new Color(255, 0, 0);

              addHoverEffect(b1,   yellowgreen, Color.WHITE);
              addHoverEffect(b2,   blue, Color.WHITE);
              addHoverEffect(b3,   red, Color.WHITE);
              
         
         jTable1.getColumnModel().getColumn(0).setPreferredWidth(30);
         jTable1.getColumnModel().getColumn(1).setPreferredWidth(200);
     //-----------------------------------------------------------------------------------------------------------------------------------------    
    //Kani is same lng sa Products nga Table para Gwapo sd tan-awon ba!!
    java.awt.Color green  = new java.awt.Color(46, 125, 50);
    java.awt.Color altRow = new java.awt.Color(244, 250, 244);
    java.awt.Color select = new java.awt.Color(200, 230, 201);

    jTable1.setRowHeight(34);
    jTable1.setFont(new java.awt.Font("Segoe UI", java.awt.Font.PLAIN, 15));
    jTable1.setShowGrid(false);
    jTable1.setIntercellSpacing(new java.awt.Dimension(0, 0));
    jTable1.setSelectionBackground(select);
    jTable1.setSelectionForeground(java.awt.Color.BLACK);
    jTable1.setFillsViewportHeight(true);

    jTable1.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
        @Override
        public java.awt.Component getTableCellRendererComponent(javax.swing.JTable t,
                Object v, boolean sel, boolean foc, int row, int col) {
            super.getTableCellRendererComponent(t, v, sel, false, row, col);
            setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 12, 0, 12));
            setBackground(sel ? select : (row % 2 == 0 ? java.awt.Color.WHITE : altRow));
            setForeground(java.awt.Color.BLACK);
            return this;
        }
    });
    
    jTable1.getTableHeader().setDefaultRenderer(new javax.swing.table.DefaultTableCellRenderer() {
        @Override
        public java.awt.Component getTableCellRendererComponent(javax.swing.JTable t,
                Object v, boolean sel, boolean foc, int row, int col) {
            super.getTableCellRendererComponent(t, v, false, false, row, col);
            setBackground(green);
            setForeground(java.awt.Color.WHITE);
            setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 15));
            setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            return this;
        }
    });
    
    jTable1.getTableHeader().setPreferredSize(new java.awt.Dimension(0, 38));
    jTable1.getColumnModel().getColumn(0).setPreferredWidth(150);
    jTable1.getColumnModel().getColumn(1).setPreferredWidth(150);
    jTable1.getColumnModel().getColumn(2).setPreferredWidth(90);
   }//------------------------------------------------------------------------------------------------------------------------------------------
    
     //Kani is para ma kuha niya ang mga na receive niya na data sa another childclass, then para maka pay!! 
    public void addtable(int ID, String ProductName, String category, Double Price){
         DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();
         
         DecimalFormat df = new DecimalFormat("₱ 00.00");
           double totPrice = Price * Double.valueOf(category);
           
           String TotalPrice = df.format(totPrice );
         
          for (int row = 0; row < jTable1.getRowCount(); row++){
             if (ProductName == jTable1.getValueAt(row, 1)){
                 dt.removeRow(jTable1.convertRowIndexToModel(row));
             }
          }
         
          Vector v = new Vector();
    }
       public void cal(){
          int numOfRow = jTable1.getRowCount();
          double tot = 0.0;
          
          for (int  i = 0; i < numOfRow; i++){
              double value = Double.valueOf(jTable1.getValueAt(i, 3).toString());
              tot += value;
          }
          DecimalFormat df = new DecimalFormat("₱ 00.00");
          Total.setText(df.format(tot));
    } 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TxT = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        b1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Total = new javax.swing.JLabel();
        bal = new javax.swing.JLabel();
        tot = new javax.swing.JLabel();
        pay = new javax.swing.JTextField();
        b2 = new javax.swing.JButton();
        b3 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TxT.setBackground(new java.awt.Color(222, 222, 254));
        TxT.setColumns(20);
        TxT.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 12)); // NOI18N
        TxT.setRows(5);
        jScrollPane1.setViewportView(TxT);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 50, 300, 520));

        jPanel2.setBackground(new java.awt.Color(0, 102, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        b1.setBackground(new java.awt.Color(0, 102, 0));
        b1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        b1.setForeground(new java.awt.Color(255, 255, 255));
        b1.setText("Pay");
        b1.setBorder(null);
        b1.addActionListener(this::b1ActionPerformed);
        jPanel2.add(b1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 100, 40));

        jLabel1.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cash :");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, 60, 20));

        jLabel2.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Balance :");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 90, 20));

        Total.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 16)); // NOI18N
        Total.setForeground(new java.awt.Color(255, 255, 255));
        Total.setText("0");
        jPanel2.add(Total, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, 100, 20));

        bal.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 16)); // NOI18N
        bal.setForeground(new java.awt.Color(255, 255, 255));
        bal.setText("0");
        jPanel2.add(bal, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 100, 100, 20));

        tot.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        tot.setForeground(new java.awt.Color(255, 255, 255));
        tot.setText("Total :");
        jPanel2.add(tot, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 60, 20));

        pay.setBackground(new java.awt.Color(0, 102, 0));
        pay.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 16)); // NOI18N
        pay.setForeground(new java.awt.Color(255, 255, 255));
        pay.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 1, 1, 1, new java.awt.Color(255, 255, 255)));
        pay.addActionListener(this::payActionPerformed);
        jPanel2.add(pay, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 100, -1));

        b2.setBackground(new java.awt.Color(0, 102, 0));
        b2.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        b2.setForeground(new java.awt.Color(255, 255, 255));
        b2.setText("Print");
        b2.setBorder(null);
        b2.addActionListener(this::b2ActionPerformed);
        jPanel2.add(b2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 110, 40));

        b3.setBackground(new java.awt.Color(0, 102, 0));
        b3.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 14)); // NOI18N
        b3.setForeground(new java.awt.Color(255, 255, 255));
        b3.setText("Delete");
        b3.setBorder(null);
        b3.addActionListener(this::b3ActionPerformed);
        jPanel2.add(b3, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 140, 100, 40));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 390, 370, 190));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Product Name", "Category", "Price"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        jPanel1.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 350, 340));

        jLabel4.setFont(new java.awt.Font("Rockwell Extra Bold", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("PAYING BILLS");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 676, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void b1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b1ActionPerformed
    try {
        //Kani is para mag popUp ang Peso sign sa Table/Price!!
        double totalDue = Double.parseDouble(
                Total.getText().replace("₱", "").replace(",", "").trim());
        double paid = Double.parseDouble(pay.getText().trim());
        
         //Dri og kulang imong gi bayad kay dli ka maka palit hahaha!!
        if (paid < totalDue) {
            javax.swing.JOptionPane.showMessageDialog(this, "Cash is not enough.");
            return;
        }

        double balance = paid - totalDue;
        DecimalFormat df = new DecimalFormat("#,##0.00");
        bal.setText("₱ " + df.format(balance));

    } catch (NumberFormatException ex) {         
        javax.swing.JOptionPane.showMessageDialog(this, "Please enter a valid cash amount.");
    }
      
    }//GEN-LAST:event_b1ActionPerformed

    private void b2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b2ActionPerformed
   try {
    javax.swing.table.DefaultTableModel model =
        (javax.swing.table.DefaultTableModel) jTable1.getModel();

    // Kani kay para sa TextArea para pag print nato ma copy niya ang mga text nga gipang butang nko dri!!
    String now = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
            .format(new java.util.Date());

    TxT.setFont(new java.awt.Font("Monospaced", java.awt.Font.PLAIN, 13));
    TxT.setText("");
  
    TxT.append("             Mini Mart\n");
    TxT.append("            Davao City\n");
    TxT.append("           09559873593\n\n");
    TxT.append("Date & Time: " + now + "\n");
    TxT.append("-----------------------------------------\n");
    TxT.append(String.format("%-16s %-14s %8s\n", "Product Name", "Category", "Price"));
    TxT.append("-----------------------------------------\n");

    // Kani nga loop kay gina copy taga row sa table para ma convert niya into receipt!!
    for (int i = 0; i < model.getRowCount(); i++) {
        String name = model.getValueAt(i, 0).toString();
        String category = model.getValueAt(i, 1).toString();
        String price = model.getValueAt(i, 2).toString();
        TxT.append(String.format("%-16s %-14s %8s\n", name, category, price));
    }

    // Dinhi nga side kay ma recieve sa TextArea ang mga Total,Cash,Balance pag gi print na nato!!
    TxT.append("-----------------------------------------\n");
    TxT.append("Sub Total : " + Total.getText() + "\n");
    TxT.append("Cash      : ₱" + pay.getText() + "\n");
    TxT.append("Balance   : " + bal.getText() + "\n");
    TxT.append("-----------------------------------------\n");
    TxT.append("   Thank you, and come back again......!\n");
    TxT.append("-----------------------------------------\n");
   
    // NEW: opens the printer window (choose printer / Microsoft Print to PDF, then Print)
    boolean printed = TxT.print();
    if (!printed) {
        javax.swing.JOptionPane.showMessageDialog(this, "Printing was cancelled.");
    }

} catch (java.awt.print.PrinterException pe) {
    javax.swing.JOptionPane.showMessageDialog(this,
        "Printer error: " + pe.getMessage(),
        "Print Error",
        javax.swing.JOptionPane.ERROR_MESSAGE);
} catch (Exception e) {
    System.out.println(e);
}
    }//GEN-LAST:event_b2ActionPerformed

    private void b3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b3ActionPerformed
    //Dri is kuhaon sa user ang row, and dapat ang user kay nka selected na sa table!!
    int row = jTable1.getSelectedRow();
    if (row == -1) return;

    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    String priceText = model.getValueAt(row, 2).toString().replace("₱", "").replace(",", "").trim();
    totalAmount -= Double.parseDouble(priceText);

    model.removeRow(row);
    Total.setText("₱ " + new DecimalFormat("#,##0.00").format(totalAmount)); //Dri kay gina Show niya ang updated total sa Total label!!   
    }//GEN-LAST:event_b3ActionPerformed

    private void payActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_payActionPerformed
     public static void main(String args[]) {  
        java.awt.EventQueue.invokeLater(() -> new PayList().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Total;
    private javax.swing.JTextArea TxT;
    private javax.swing.JButton b1;
    private javax.swing.JButton b2;
    private javax.swing.JButton b3;
    private javax.swing.JLabel bal;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField pay;
    private javax.swing.JLabel tot;
    // End of variables declaration//GEN-END:variables
}
