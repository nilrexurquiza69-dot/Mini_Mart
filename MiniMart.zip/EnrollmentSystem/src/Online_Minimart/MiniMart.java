
package Online_Minimart;

           
public class MiniMart {        
                 
                               
    public static void main(String[] args) {
       OpenPage x = new OpenPage();
       x.setVisible(true);
       x.pack();   
       x.setLocationRelativeTo(null);
    }
    
}
